/* ═══════════════════════════════════════════════
   AEROSIM — app.js
═══════════════════════════════════════════════ */

const WA_LINK = (plan) => {
  const msg = encodeURIComponent(
    `Hi AeroSim! 👋\n\nI'd like to purchase the following eSIM plan:\n\n` +
    `📍 Country: ${plan.country} ${plan.flag}\n` +
    `📶 Data: ${plan.data}\n` +
    `⏱️ Validity: ${plan.validity}\n` +
    `💵 Price: $${plan.usd} (₦${plan.ngn.toLocaleString()})\n\n` +
    `Please guide me on how to proceed. Thank you!`
  );
  return `https://wa.me/${WA_NUMBER}?text=${msg}`;
};
const WA_CHAT = () => {
  const msg = encodeURIComponent("Hi AeroSim! 👋 I'd like to know more about your eSIM plans. Can you help me?");
  return `https://wa.me/${WA_NUMBER}?text=${msg}`;
};

/* ── SVG helpers ── */
const SVG = {
  wifi: `<svg viewBox="0 0 24 24"><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/></svg>`,
  clock: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
  zap: `<svg viewBox="0 0 24 24"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,
  globe: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>`,
  shield: `<svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
  headphones: `<svg viewBox="0 0 24 24"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3z"/><path d="M3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>`,
  chevronDown: `<svg viewBox="0 0 24 24" class="chevron"><polyline points="6 9 12 15 18 9"/></svg>`,
  arrow: `<svg viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>`,
  arrowLeft: `<svg viewBox="0 0 24 24"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>`,
  sliders: `<svg viewBox="0 0 24 24"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>`,
  search: `<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
  check: `<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>`,
  phone: `<svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 2.18h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`,
  mapPin: `<svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>`,
  waIcon: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>`,
};

/* ══════════════════════════════════════════════
   STATE
══════════════════════════════════════════════ */
const state = {
  page: 'home',       // 'home' | 'plans' | 'detail'
  planId: null,
  filters: { country:'', dataGB:'', validityDays:'', region:'All' },
};

/* ══════════════════════════════════════════════
   ROUTER
══════════════════════════════════════════════ */
function navigate(page, planId = null) {
  state.page = page;
  state.planId = planId;
  window.scrollTo({ top: 0, behavior: 'instant' });
  render();
  // update URL hash
  if (page === 'home') history.pushState({}, '', '#');
  else if (page === 'plans') history.pushState({}, '', '#plans');
  else if (page === 'detail') history.pushState({}, '', `#plan-${planId}`);
}

function handleHash() {
  const h = location.hash;
  if (!h || h === '#') { state.page = 'home'; state.planId = null; }
  else if (h === '#plans') { state.page = 'plans'; state.planId = null; }
  else if (h.startsWith('#plan-')) {
    const id = parseInt(h.replace('#plan-', ''));
    state.page = 'detail'; state.planId = id;
  } else if (h === '#how-it-works' || h === '#faq') {
    state.page = 'home'; state.planId = null;
    render();
    setTimeout(() => {
      const el = document.querySelector(h);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 60);
    return;
  }
  render();
}

/* ══════════════════════════════════════════════
   FILTER LOGIC
══════════════════════════════════════════════ */
function filteredPlans() {
  let list = PLANS;
  const { country, dataGB, validityDays, region } = state.filters;
  if (country) list = list.filter(p => p.country.toLowerCase().includes(country.toLowerCase()));
  if (dataGB) list = list.filter(p => p.dataGB === +dataGB);
  if (validityDays) list = list.filter(p => p.days === +validityDays);
  if (region && region !== 'All') list = list.filter(p => p.region === region);
  return list;
}

/* ══════════════════════════════════════════════
   COMPONENTS
══════════════════════════════════════════════ */
function PlanCard(plan) {
  return `
  <div class="plan-card glass" onclick="navigate('detail',${plan.id})">
    <div class="card-head">
      <div class="card-country">
        <span class="card-flag">${plan.flag}</span>
        <div>
          <div class="card-name">${plan.country}</div>
          <div class="card-network">${SVG.wifi} ${plan.network}</div>
        </div>
      </div>
      ${plan.popular ? `<span class="badge-gold">⭐ Popular</span>` : ''}
      ${plan.bestValue ? `<span class="badge-best-value">✦ Best Value</span>` : ''}
    </div>
    <div class="card-specs">
      <div class="spec-box">
        <div class="spec-val">${plan.data}</div>
        <div class="spec-key">Data</div>
      </div>
      <div class="spec-box">
        <div class="spec-val" style="font-size:.95rem;font-family:var(--font-b);color:var(--text)">${plan.validity}</div>
        <div class="spec-key">Validity</div>
      </div>
    </div>
    <div class="card-footer">
      <div>
        <div class="price-usd">$${plan.usd}</div>
        <div class="price-ngn">₦${plan.ngn.toLocaleString()}</div>
        ${plan.bestValue ? '<div class="savings-callout"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Save up to 80% vs roaming</div>' : ''}
      </div>
      <button class="card-btn">Details ${SVG.arrow}</button>
    </div>
  </div>`;
}

/* ══════════════════════════════════════════════
   PAGES
══════════════════════════════════════════════ */
function renderHome() {
  const popular = PLANS.filter(p => p.popular).slice(0, 3);
  const countries = [...new Set(PLANS.map(p => p.country))].length;

  return `
  <!-- HERO -->
  <section class="hero">
    <div class="hero-orb orb-1"></div>
    <div class="hero-orb orb-2"></div>
    <div class="hero-orb orb-3"></div>
    <div class="hero-content">
      <div class="badge-pill" style="margin-bottom:28px">
        <span class="dot-pulse"></span>
        Instant eSIM Delivery via WhatsApp
      </div>
      <h1 class="hero-title">
        Stay Connected<br>
        <span class="gold-shimmer">Everywhere</span><br>
        <span class="italic">You Travel</span>
      </h1>
      <p class="hero-sub">
        Premium eSIM data plans for ${countries}+ countries. No physical SIM needed.
        Order in seconds on WhatsApp and connect instantly on arrival.
      </p>
      <div class="hero-btns">
        <button class="btn-gold" onclick="navigate('plans')">
          View eSIM Plans ${SVG.arrow}
        </button>
        <a href="${WA_CHAT()}" target="_blank" class="btn-outline">
          ${SVG.waIcon} Chat on WhatsApp
        </a>
      </div>
      <div class="hero-stats">
        <div class="stat-item"><div class="stat-num">${countries}+</div><div class="stat-label">Countries</div></div>
        <div class="stat-item"><div class="stat-num">30min</div><div class="stat-label">Avg Delivery</div></div>
        <div class="stat-item"><div class="stat-num">24/7</div><div class="stat-label">Support</div></div>
      </div>
    </div>
  </section>

  <!-- FEATURES -->
  <section class="section">
    <div class="wrap">
      <div class="section-label">Why AeroSim</div>
      <h2 class="section-title">The Smarter Way to Roam</h2>
      <div class="features-grid">
        ${[
          {icon:'globe', title:'Global Coverage', desc:`Premium eSIM plans covering ${countries}+ countries across all major regions.`},
          {icon:'zap', title:'Instant Delivery', desc:'Receive your eSIM QR code via WhatsApp within minutes of ordering.'},
          {icon:'shield', title:'No Hidden Fees', desc:'Transparent dual pricing in USD and NGN. What you see is what you pay.'},
          {icon:'headphones', title:'24/7 WhatsApp Support', desc:'Our team is always available on WhatsApp to help with setup or issues.'},
        ].map(f => `
          <div class="feature-card glass">
            <div class="feature-icon">${SVG[f.icon]}</div>
            <div class="feature-title">${f.title}</div>
            <div class="feature-desc">${f.desc}</div>
          </div>`).join('')}
      </div>
    </div>
  </section>

  <!-- FEATURED PLANS -->
  <section class="section" style="padding-top:0">
    <div class="wrap">
      <div class="section-label">Top Picks</div>
      <h2 class="section-title">Most Popular Plans</h2>
      <p class="section-sub" style="margin-top:10px">Our travellers save up to <strong style="color:var(--gold)">80%</strong> vs standard roaming charges. Pick the plan that fits your trip.</p>
      <div class="featured-grid" style="margin-top:36px">
        ${popular.map(p => PlanCard(p)).join('')}
      </div>
      <div style="text-align:center;margin-top:32px">
        <button class="btn-outline" onclick="navigate('plans')">See All Plans ${SVG.arrow}</button>
      </div>
    </div>
  </section>

  <!-- HOW IT WORKS -->
  <section class="section hiw-bg" id="how-it-works">
    <div class="wrap">
      <div style="text-align:center">
        <div class="section-label" style="text-align:center">Process</div>
        <h2 class="section-title" style="text-align:center">How It Works</h2>
        <p class="section-sub" style="margin:12px auto 0;text-align:center">From browsing to connected — three simple steps.</p>
      </div>
      <div class="hiw-grid">
        ${[
          {num:'01', title:'Buy Plan', desc:'Browse eSIM plans for your destination, select your data size and validity, then tap Purchase — it takes under a minute.'},
          {num:'02', title:'Receive QR Code', desc:'After confirming payment on WhatsApp, we send your personal eSIM QR code directly to your chat — instantly.'},
          {num:'03', title:'Scan & Activate', desc:"Open your phone's eSIM settings, scan the QR code, and you're live. No physical SIM, no waiting, no roaming fees."},
        ].map(s => `
          <div class="hiw-step">
            <div class="hiw-num">${s.num}</div>
            <div>
              <div class="hiw-title">${s.title}</div>
              <div class="hiw-desc" style="margin-top:8px">${s.desc}</div>
            </div>
          </div>`).join('')}
      </div>
    </div>
  </section>

  <!-- FAQ -->
  <section class="section" id="faq">
    <div class="wrap">
      <div style="text-align:center">
        <div class="section-label" style="text-align:center">Help Center</div>
        <h2 class="section-title" style="text-align:center">Frequently Asked Questions</h2>
      </div>
      <div class="faq-list">
        ${[
          {q:'What is an eSIM?', a:'An eSIM (embedded SIM) is a digital SIM card built into your device. It allows you to activate a mobile plan without needing a physical SIM card — perfect for international travel.'},
          {q:'How do I know if my device supports eSIM?', a:'Most iPhones from XS onwards, Google Pixel 3+, Samsung Galaxy S20+, and many other modern smartphones support eSIM. Check your device settings under "Cellular" or "Mobile Data" for an "Add eSIM" option.'},
          {q:'How fast will I receive my eSIM?', a:'Orders are typically processed within 15–30 minutes during business hours. After payment confirmation via WhatsApp, your QR code is sent directly to your chat.'},
          {q:'Can I use WhatsApp or social media with this eSIM?', a:'Yes! All our eSIM plans provide standard mobile data, so you can use any app that requires internet — WhatsApp, Instagram, Google Maps, and more.'},
          {q:'What happens if my data runs out?', a:'Once your data is exhausted, you can purchase a top-up plan. Contact us via WhatsApp and we\'ll set you up with additional data for your current or new destination.'},
          {q:'Do you offer refunds?', a:'If an eSIM fails to activate through no fault of your own, we\'ll issue a full replacement or refund. Please contact us via WhatsApp within 24 hours of purchase.'},
        ].map(f => `
          <details class="faq-item glass">
            <summary>${f.q} ${SVG.chevronDown}</summary>
            <div class="faq-body"><div class="glow-line" style="margin-bottom:14px"></div><p>${f.a}</p></div>
          </details>`).join('')}
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="section" style="padding-bottom:48px">
    <div class="wrap">
      <div class="cta-banner">
        <div class="orb-bg"></div>
        <div class="section-label" style="text-align:center">Ready to Connect?</div>
        <h2 class="section-title" style="text-align:center;margin-top:4px">Your Next Trip, Covered.</h2>
        <p style="color:var(--text-2);margin-top:12px;font-size:.95rem;max-width:460px;margin-left:auto;margin-right:auto;text-align:center;line-height:1.7">
          Browse plans now or chat with us on WhatsApp — we'll help you find the perfect eSIM for your destination.
        </p>
        <div class="cta-btns">
          <button class="btn-gold" onclick="navigate('plans')">Browse All Plans ${SVG.arrow}</button>
          <a href="${WA_CHAT()}" target="_blank" class="btn-outline">${SVG.waIcon} +234 701 633 6519</a>
        </div>
      </div>
    </div>
  </section>`;
}

/* ── PLANS PAGE ── */
function renderPlans() {
  const list = filteredPlans();
  const { filters } = state;

  return `
  <div class="plans-header">
    <div class="orb-bg"></div>
    <div class="wrap" style="position:relative;z-index:1">
      <a href="#" onclick="navigate('home');return false;" class="breadcrumb" style="display:inline-flex;margin-bottom:16px">
        ${SVG.arrowLeft} Back to Home
      </a>
      <div class="plans-header-inner">
        <div>
          <div class="section-label">Browse Plans</div>
          <h1 class="section-title">eSIM Plans</h1>
          <div class="plans-count">${list.length} plan${list.length!==1?'s':''} found</div>
        </div>
      </div>
      <div class="region-tabs">
        ${REGIONS.map(r => `
          <button class="region-tab ${(filters.region===r||(r==='All'&&!filters.region||filters.region==='All'&&r==='All'))?'active':''}"
            onclick="setRegion('${r}')">${r}</button>`).join('')}
      </div>
    </div>
  </div>
  <div class="plans-body">
    <div class="wrap">
      <div class="plans-layout">
        <aside class="sidebar">
          <div class="filter-card glass">
            <div class="filter-title">${SVG.sliders} Filters</div>
            <div class="filter-group">
              <label class="filter-label">Country</label>
              <div class="aura-search-wrap">
                <div class="aura-blob aura-blob-1"></div>
                <div class="aura-blob aura-blob-2"></div>
                <div class="aura-blob aura-blob-3"></div>
                <input type="text" class="filter-input" placeholder="Search country..." value="${filters.country||''}"
                  oninput="setFilter('country',this.value)" />
              </div>
            </div>
            <div class="filter-group">
              <label class="filter-label">Data Size</label>
              <div class="filter-chips">
                ${[{l:'All',v:''},{l:'3GB',v:'3'},{l:'5GB',v:'5'},{l:'10GB',v:'10'},{l:'20GB',v:'20'}].map(o=>`
                  <button class="chip ${String(filters.dataGB)===o.v?'active':''}" onclick="setFilter('dataGB','${o.v}')">${o.l}</button>`).join('')}
              </div>
            </div>
            <div class="filter-group">
              <label class="filter-label">Validity</label>
              <div class="filter-chips">
                ${[{l:'Any',v:''},{l:'7 Days',v:'7'},{l:'15 Days',v:'15'},{l:'30 Days',v:'30'}].map(o=>`
                  <button class="chip ${String(filters.validityDays)===o.v?'active':''}" onclick="setFilter('validityDays','${o.v}')">${o.l}</button>`).join('')}
              </div>
            </div>
            ${(filters.country||filters.dataGB||filters.validityDays||(filters.region&&filters.region!=='All'))?`
            <button class="clear-btn" onclick="clearFilters()">✕ Clear all filters</button>`:''}
          </div>
        </aside>
        <main class="plans-main">
          ${list.length===0 ? `
          <div class="empty-state">
            <div class="empty-icon">${SVG.search}</div>
            <div class="empty-title">No plans found</div>
            <div class="empty-sub">Try adjusting your filters or browse all available plans.</div>
            <button class="btn-outline btn-sm" style="margin-top:8px" onclick="clearFilters()">Clear Filters</button>
          </div>` : `
          <div class="plans-grid">${list.map(p=>PlanCard(p)).join('')}</div>`}
        </main>
      </div>
    </div>
  </div>`;
}

/* ── DETAIL PAGE ── */
function renderDetail() {
  const plan = PLANS.find(p => p.id === state.planId);
  if (!plan) { navigate('plans'); return ''; }

  const related = PLANS.filter(p => p.country === plan.country && p.id !== plan.id);
  const waLink = WA_LINK(plan);

  return `
  <div class="detail-page">
    <div class="wrap">
      <div class="breadcrumb">
        <a href="#" onclick="navigate('home');return false;">Home</a>
        ${SVG.arrowLeft.replace('arrowLeft','chevron-right')} <svg viewBox="0 0 24 24" style="width:12px;height:12px;stroke:var(--text-3);fill:none;stroke-width:2"><polyline points="9 18 15 12 9 6"/></svg>
        <a href="#" onclick="navigate('plans');return false;">Plans</a>
        <svg viewBox="0 0 24 24" style="width:12px;height:12px;stroke:var(--text-3);fill:none;stroke-width:2"><polyline points="9 18 15 12 9 6"/></svg>
        <span>${plan.country}</span>
      </div>

      <div class="detail-grid">
        <!-- LEFT MAIN -->
        <div class="detail-main">
          <!-- Hero card -->
          <div class="glass detail-hero-card">
            <div class="orb-bg"></div>
            <div class="detail-flag-row">
              <span class="detail-flag">${plan.flag}</span>
              <div>
                <div class="detail-country">${plan.country}</div>
                <div class="detail-network">${SVG.wifi} ${plan.network}</div>
                ${plan.popular ? `<span class="badge-gold" style="margin-top:8px;display:inline-flex">⭐ Popular</span>` : ''}
              </div>
            </div>
            <div class="detail-specs">
              ${[
                {icon:'wifi', label:'Data', val:plan.data},
                {icon:'clock', label:'Validity', val:plan.validity},
                {icon:'zap', label:'Speed', val:'4G/5G'},
                {icon:'globe', label:'Region', val:plan.region},
              ].map(s=>`
              <div class="detail-spec-box">
                <svg class="detail-spec-icon" viewBox="0 0 24 24">${SVG[s.icon].match(/>(.+)<\/svg>/s)?.[1]||''}</svg>
                <div class="detail-spec-val">${s.val}</div>
                <div class="detail-spec-key">${s.label}</div>
              </div>`).join('')}
            </div>
            <div class="detail-price-row">
              <div>
                <div style="font-size:.75rem;color:var(--text-2);margin-bottom:4px">Plan Price</div>
                <div class="detail-usd">$${plan.usd}</div>
                <div class="detail-usd-label">USD</div>
              </div>
              <div style="text-align:right">
                <div class="detail-ngn">₦${plan.ngn.toLocaleString()}</div>
                <div class="detail-ngn-note">NGN (approx)</div>
              </div>
            </div>
          </div>

          <!-- Benefits -->
          <div class="glass benefits-card">
            <div class="benefits-title">${SVG.shield} What's Included</div>
            <div class="benefits-grid">
              ${plan.benefits.map(b=>`
              <div class="benefit-item">
                <div class="benefit-check">${SVG.check}</div>
                <span class="benefit-text">${b}</span>
              </div>`).join('')}
            </div>
          </div>

          <!-- Activation -->
          <div class="glass activation-card">
            <div class="activation-title">Activation Details</div>
            <div class="activation-rows">
              ${[
                {k:'Delivery', v:'Instant digital delivery via WhatsApp'},
                {k:'Compatible', v:'iPhone XS+, Samsung Galaxy S20+, and most eSIM-enabled devices'},
                {k:'Network', v:plan.network},
                {k:'Activation', v:'Scan QR code in your device eSIM settings'},
              ].map(r=>`
              <div class="activation-row">
                <span class="activation-key">${r.k}</span>
                <span class="activation-val">${r.v}</span>
              </div>`).join('')}
            </div>
          </div>
        </div>

        <!-- RIGHT PURCHASE -->
        <div class="detail-sticky">
          <div class="glass purchase-card">
            <div class="purchase-card-title">Order Summary</div>
            <span class="purchase-flag">${plan.flag}</span>
            <div class="purchase-name">${plan.country}</div>
            <div class="purchase-sub">${plan.data} · ${plan.validity}</div>
            <div class="glow-line" style="margin:18px 0"></div>
            <div class="purchase-price">
              <div class="purchase-usd">$${plan.usd}</div>
              <div class="purchase-ngn">₦${plan.ngn.toLocaleString()}</div>
            </div>
            <a href="${waLink}" target="_blank" rel="noopener noreferrer" class="purchase-btn">
              ${SVG.waIcon} Purchase via WhatsApp
            </a>
            <div class="purchase-note">Clicking opens WhatsApp with your order pre-filled. No payment on this site.</div>
          </div>

          <div class="glass trust-card">
            ${[
              {e:'⚡', t:'Delivered within 30 minutes'},
              {e:'🔒', t:'Secure order via WhatsApp'},
              {e:'💬', t:'24/7 customer support'},
              {e:'🌐', t:'Works in 30+ countries'},
            ].map(i=>`
            <div class="trust-item">
              <span class="trust-emoji">${i.e}</span>
              <span class="trust-text">${i.t}</span>
            </div>`).join('')}
          </div>
        </div>
      </div>

      ${related.length>0 ? `
      <div class="related-section">
        <div class="related-title">More ${plan.country} Plans</div>
        <div class="related-grid">
          ${related.map(p=>`
          <div class="related-card" onclick="navigate('detail',${p.id})">
            <div class="related-left">
              <span class="related-flag">${p.flag}</span>
              <div>
                <div class="related-info-name">${p.data}</div>
                <div class="related-info-sub">${p.validity}</div>
              </div>
            </div>
            <div class="related-right">
              <div class="related-price">$${p.usd}</div>
              <div class="related-arrow">→</div>
            </div>
          </div>`).join('')}
        </div>
      </div>` : ''}

      <div style="margin-top:40px">
        <button onclick="navigate('plans')" style="display:inline-flex;align-items:center;gap:6px;font-size:.82rem;color:var(--text-2);cursor:pointer;transition:color .2s" onmouseover="this.style.color='var(--gold)'" onmouseout="this.style.color='var(--text-2)'">
          ${SVG.arrowLeft} Browse All Plans
        </button>
      </div>
    </div>
  </div>`;
}

/* ══════════════════════════════════════════════
   NAVBAR HTML
══════════════════════════════════════════════ */
function renderNavbar() {
  return `
  <nav id="navbar">
    <div class="wrap">
      <div class="nav-inner">
        <div class="logo" onclick="navigate('home')">
          <div class="logo-icon">
            <svg viewBox="0 0 24 24"><path d="M5 12.55a11 11 0 0 1 14.08 0M1.42 9a16 16 0 0 1 21.16 0M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01"/></svg>
          </div>
          <div class="logo-text">Aero<span>Sim</span></div>
        </div>
        <div class="nav-links">
          <a href="#" onclick="navigate('home');return false;">Home</a>
          <a href="#" onclick="navigate('plans');return false;">eSIM Plans</a>
          <a href="#how-it-works" onclick="navigate('home');setTimeout(()=>document.querySelector('#how-it-works')?.scrollIntoView({behavior:'smooth'}),80);return false;">How It Works</a>
          <a href="#faq" onclick="navigate('home');setTimeout(()=>document.querySelector('#faq')?.scrollIntoView({behavior:'smooth'}),80);return false;">FAQ</a>
          <a href="${WA_CHAT()}" target="_blank" class="nav-cta">${SVG.waIcon} WhatsApp Us</a>
        </div>
        <button class="hamburger" id="hamburger" onclick="toggleMenu()" aria-label="Menu">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
    <div class="mobile-menu" id="mobile-menu">
      <a href="#" onclick="navigate('home');closeMenu();return false;">Home</a>
      <a href="#" onclick="navigate('plans');closeMenu();return false;">eSIM Plans</a>
      <a href="#how-it-works" onclick="navigate('home');setTimeout(()=>document.querySelector('#how-it-works')?.scrollIntoView({behavior:'smooth'}),80);closeMenu();return false;">How It Works</a>
      <a href="#faq" onclick="navigate('home');setTimeout(()=>document.querySelector('#faq')?.scrollIntoView({behavior:'smooth'}),80);closeMenu();return false;">FAQ</a>
      <div class="divider-line"></div>
      <a href="${WA_CHAT()}" target="_blank" class="mobile-wa" onclick="closeMenu()">${SVG.waIcon} Chat on WhatsApp</a>
    </div>
  </nav>`;
}

function renderFooter() {
  const year = new Date().getFullYear();
  return `
  <footer>
    <div class="wrap">
      <div class="footer-grid">
        <div>
          <div class="logo" onclick="navigate('home')" style="cursor:pointer">
            <div class="logo-icon">
              <svg viewBox="0 0 24 24"><path d="M5 12.55a11 11 0 0 1 14.08 0M1.42 9a16 16 0 0 1 21.16 0M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01"/></svg>
            </div>
            <div class="logo-text">Aero<span>Sim</span></div>
          </div>
          <p class="footer-brand-desc">Premium eSIM plans for 30+ countries. Instant delivery via WhatsApp. No hidden fees. Stay connected wherever life takes you.</p>
          <div class="footer-contact">
            <div class="footer-contact-item">${SVG.phone}<a href="${WA_CHAT()}" target="_blank">+234 701 633 6519</a></div>
            <div class="footer-contact-item">${SVG.mapPin}<span>Lagos, Nigeria</span></div>
          </div>
        </div>
        <div>
          <div class="footer-col-title">Quick Links</div>
          <div class="footer-links">
            <a href="#" onclick="navigate('plans');return false;">eSIM Plans</a>
            <a href="#how-it-works" onclick="navigate('home');setTimeout(()=>document.querySelector('#how-it-works')?.scrollIntoView({behavior:'smooth'}),80);return false;">How It Works</a>
            <a href="#faq" onclick="navigate('home');setTimeout(()=>document.querySelector('#faq')?.scrollIntoView({behavior:'smooth'}),80);return false;">FAQ</a>
            <a href="${WA_CHAT()}" target="_blank">WhatsApp Support</a>
          </div>
        </div>
        <div>
          <div class="footer-col-title">Coverage</div>
          <div class="footer-links">
            ${['Americas','Europe','Middle East','Africa','Asia Pacific'].map(r=>`
            <a href="#" onclick="state.filters.region='${r}';navigate('plans');return false;">${r}</a>`).join('')}
          </div>
        </div>
      </div>
      <div class="glow-line"></div>
      <div class="footer-bottom" style="margin-top:24px">
        <div class="footer-copy">© ${year} AeroSim. All rights reserved.</div>
        <div class="footer-note">Prices in USD & NGN for reference. Final pricing confirmed via WhatsApp.</div>
      </div>
    </div>
  </footer>`;
}

function renderWAFloat() {
  return `
  <div id="wa-float">
    <a href="${WA_CHAT()}" target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp">
      <div class="wa-tooltip">
        <span class="wa-tooltip-text">Chat on WhatsApp</span>
        <span class="wa-tooltip-num">+234 701 633 6519</span>
      </div>
      <div class="wa-btn">${SVG.waIcon}</div>
    </a>
  </div>`;
}

/* ══════════════════════════════════════════════
   MAIN RENDER
══════════════════════════════════════════════ */
function render() {
  const app = document.getElementById('page-content');
  if (!app) return;
  let content = '';
  if (state.page === 'home') content = renderHome();
  else if (state.page === 'plans') content = renderPlans();
  else if (state.page === 'detail') content = renderDetail();

  app.innerHTML = content;

  // Re-bind navbar scroll
  initNavScroll();
}

function renderShell() {
  document.body.innerHTML = `
    ${renderNavbar()}
    <div id="page-content"></div>
    ${renderFooter()}
    ${renderWAFloat()}
  `;
  render();
  initNavScroll();
}


/* ══════════════════════════════════════════════
   FILTERS
══════════════════════════════════════════════ */
function setFilter(key, val) {
  state.filters[key] = val;
  if (state.page !== 'plans') state.page = 'plans';
  render();
  // keep input focus
  if (key === 'country') {
    const inp = document.querySelector('.filter-input');
    if (inp) { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }
  }
}
function setRegion(r) {
  state.filters.region = r === 'All' ? 'All' : r;
  state.page = 'plans';
  render();
}
function clearFilters() {
  state.filters = { country:'', dataGB:'', validityDays:'', region:'All' };
  render();
}

/* ══════════════════════════════════════════════
   MOBILE MENU
══════════════════════════════════════════════ */
function toggleMenu() {
  const m = document.getElementById('mobile-menu');
  const h = document.getElementById('hamburger');
  m.classList.toggle('open');
  h.classList.toggle('open');
}
function closeMenu() {
  const m = document.getElementById('mobile-menu');
  const h = document.getElementById('hamburger');
  m?.classList.remove('open');
  h?.classList.remove('open');
}

/* ══════════════════════════════════════════════
   NAVBAR SCROLL
══════════════════════════════════════════════ */
function initNavScroll() {
  const nav = document.getElementById('navbar');
  if (!nav) return;
  const onScroll = () => nav.classList.toggle('scrolled', window.scrollY > 20);
  window.removeEventListener('scroll', window._navScroll);
  window._navScroll = onScroll;
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
}

/* ══════════════════════════════════════════════
   BOOT
══════════════════════════════════════════════ */
window.addEventListener('DOMContentLoaded', () => {
  renderShell();
  handleHash();
});
window.addEventListener('popstate', () => { handleHash(); });

// expose to HTML onclick
window.navigate = navigate;
window.setFilter = setFilter;
window.setRegion = setRegion;
window.clearFilters = clearFilters;
window.toggleMenu = toggleMenu;
window.closeMenu = closeMenu;
window.state = state;
